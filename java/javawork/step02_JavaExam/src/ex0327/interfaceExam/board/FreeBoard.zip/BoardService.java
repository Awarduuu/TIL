package ex0327.interfaceExam.board;

import java.util.List;

/**
 * 모든 게시물의 공통으로 사용하게 될 메소드 정의(규격서)
 * */
public interface BoardService {
	/**
	 * 등록하기
	 * @return : 0이면 등록실패, 1이상이면 등록성공
	 * */
	int insert(Board board);
	
	/**
	 * 수정하기(글번호에 해당하는 제목, 내용을 수정한다.)
	 * @return : false이면 수정실패, true이면 수정성공
	 * */
	boolean update(Board board);
	
	/**
	 * 전체 게시물 조회하기
	 * */
	List<Board> selectAll();
	
	/**
	 * 글번호에 해당하는 게시물 조회하기(글번호는 중복이 안된다)
	 * */
	Board selectByBno(int bno);

}
