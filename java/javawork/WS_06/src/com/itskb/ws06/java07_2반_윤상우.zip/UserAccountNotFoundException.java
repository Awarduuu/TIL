package com.itskb.ws06;

public class UserAccountNotFoundException extends Exception {

	public UserAccountNotFoundException(String message) {
		super(message);
	}
}
