package com.itskb.ws06;

public class BalanceLackException extends Exception {

	BalanceLackException(String message){
		super(message);
	}
}
