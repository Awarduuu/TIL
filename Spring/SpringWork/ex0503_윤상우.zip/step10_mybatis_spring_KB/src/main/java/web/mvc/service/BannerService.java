package  web.mvc.service;

import java.util.List;

public interface BannerService {
	List<String> listBanner();
}
