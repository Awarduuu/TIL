package sample11_template;

public interface BookService {
   void save(BookDTO book1, BookDTO book2);
}
