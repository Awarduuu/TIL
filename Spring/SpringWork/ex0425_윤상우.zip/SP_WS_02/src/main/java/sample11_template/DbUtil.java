package sample11_template;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component
public class DbUtil {

}
