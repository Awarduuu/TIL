package sample11_template;

import org.springframework.stereotype.Component;

@Component
public class EmailSender {

}
