package dao;

import java.util.List;

public interface BannerDAO {
	List<String> listBanner();
}
